package com.example.myapplication

import android.graphics.Bitmap

object SHARED_DATA {
    var bitmap: Bitmap? = null
}